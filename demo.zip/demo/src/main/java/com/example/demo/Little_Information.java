package com.example.demo;

public class Little_Information {
    private String CMPLNT_NUM;
    private String KY_CD;

    public Little_Information() {
    }

    public Little_Information(String CMPLNT_NUM, String KY_CD) {
        super();
        this.CMPLNT_NUM = CMPLNT_NUM;
        this.KY_CD = KY_CD;
    }

    public String getCMPLNT_NUM() {
        return CMPLNT_NUM;
    }

    public void setCMPLNT_NUM(String CMPLNT_NUM) {
        this.CMPLNT_NUM = CMPLNT_NUM;
    }

    public String getKY_CD() {
        return KY_CD;
    }

    public void setKY_CD(String KY_CD) {
        this.KY_CD = KY_CD;
    }
}
