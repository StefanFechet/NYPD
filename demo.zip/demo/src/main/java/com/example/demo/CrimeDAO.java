package com.example.demo;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Repository
public class CrimeDAO {
    private static final All_Crimes list = new All_Crimes();
    private static final TreeMap<Integer, Integer> offenses = new TreeMap<>();
    boolean read = true;
    String csv_file = "small.csv";

    void addToTree(Information info) {
        try {
            if (offenses.containsKey(Integer.parseInt(info.getKY_CD()))) {
                int val = offenses.get(Integer.parseInt(info.getKY_CD()));
                offenses.remove(Integer.parseInt(info.getKY_CD()));
                offenses.put(Integer.parseInt(info.getKY_CD()), val + 1);
            } else {
                offenses.put(Integer.parseInt(info.getKY_CD()), 1);
            }

        } catch (Exception e) {
        }
    }

    void removeFromTree(String s) {
        String[] word = s.split("\n")[8].split(" ");
        try {
            int val = offenses.get(Integer.parseInt(word[3]));
            offenses.remove(Integer.parseInt(word[3]));
            if (val > 1)
                offenses.put(Integer.parseInt(word[3]), val - 1);
        } catch (Exception e) {
        }
    }

    int generateSpecialRandom() {
        int ID = new Random().nextInt(1000000);
        boolean ok = true;
        while (ok) {
            boolean fail = false;
            if (this.getAllCrimes().getCrimesList().contains(ID))
                ID = new Random().nextInt(1000000);
            else
                ok = false;
        }
        return ID;
    }

    void readFile() throws IOException {
        this.read = false;
        CSVReader reader = new CSVReader(new FileReader(csv_file));
        String[] nextLine = new String[0];

        while (true) {
            Information info = new Information();
            try {
                if (!((nextLine = reader.readNext()) != null)) break;
            } catch (CsvValidationException e) {
                e.printStackTrace();
            }

            info.setCMPLNT_NUM(nextLine[0]);
            info.setCMPLNT_FR_DT(nextLine[1]);
            info.setCMPLNT_FR_TM(nextLine[2]);
            info.setCMPLNT_TO_DT(nextLine[3]);
            info.setCMPLNT_TO_TM(nextLine[4]);
            info.setADDR_PCT_CD(nextLine[5]);
            info.setRPT_DT(nextLine[6]);

            info.setKY_CD(nextLine[7]);
            info.setOFNS_DESC(nextLine[8]);
            info.setPD_CD(nextLine[9]);
            info.setPD_DESC(nextLine[10]);
            info.setCRM_ATPT_CPTD_CD(nextLine[11]);
            info.setLAW_CAT_CD(nextLine[12]);
            info.setBORO_NM(nextLine[13]);

            info.setLOC_OF_OCCUR_DESC(nextLine[14]);
            info.setPREM_TYP_DESC(nextLine[15]);
            info.setJURIS_DESC(nextLine[16]);
            info.setJURISDICTION_CODE(nextLine[17]);
            info.setPARKS_NM(nextLine[18]);
            info.setHADEVELOPT(nextLine[19]);
            info.setHOUSING_PSA(nextLine[20]);

            info.setX_COORD_CD(nextLine[21]);
            info.setY_COORD_CD(nextLine[22]);
            info.setSUSP_AGE_GROUP(nextLine[23]);
            info.setSUSP_RACE(nextLine[24]);
            info.setSUSP_SEX(nextLine[25]);
            info.setTRANSIT_DISTRICT(nextLine[26]);
            info.setLatitude(nextLine[27]);

            info.setLongitude(nextLine[28]);
            info.setLat_Lon(nextLine[29]);
            info.setPATROL_BORO(nextLine[30]);
            info.setSTATION_NAME(nextLine[31]);
            info.setVIC_AGE_GROUP(nextLine[32]);
            info.setVIC_RACE(nextLine[33]);
            info.setVIC_SEX(nextLine[34]);

            this.addCrime(info.toString());
            this.addToTree(info);
        }
    }

    void writeFile(Information information) {
        String[] textToWrite = new String[42];
        for (int i = 0; i < 42; i++) {
            textToWrite[i] = "";
        }
        textToWrite[0] = information.getCMPLNT_NUM();
        textToWrite[7] = information.getKY_CD();
        Path path = Paths.get(csv_file);
        try {
            Files.write(path, (Stream.of(textToWrite).collect(Collectors.joining(",")) + "\n").getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    boolean delete(String startline) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(csv_file));
            StringBuffer sb = new StringBuffer();
            int linenumber = 1;
            String line;
            while ((line = br.readLine()) != null) {
                if (linenumber < Integer.parseInt(startline) || linenumber >= Integer.parseInt(startline) + 1)
                    sb.append(line + "\n");
                linenumber++;
            }
            if (Integer.parseInt(startline) + 1 > linenumber)
                return false;
            br.close();
            FileWriter fw = new FileWriter(new File(csv_file));
            fw.write(sb.toString());
            fw.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public All_Crimes getAllCrimes() {
        try {
            if (this.read)
                this.readFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Map<Integer, Integer> getOffenses() {
        return offenses;
    }

    public void addCrime(String information) {
        list.getCrimesList().add(information);
    }
}