package com.example.demo;

import java.lang.reflect.Field;

public class Information {

    private String CMPLNT_NUM; //Randomly generated persistent ID for each complaint

    private String CMPLNT_FR_DT; //Exact date of occurrence for the reported event (or starting date of occurrence, if CMPLNT_TO_DT exists)

    private String CMPLNT_FR_TM; //Exact time of occurrence for the reported event (or starting time of occurrence, if CMPLNT_TO_TM exists)

    private String CMPLNT_TO_DT; //Ending date of occurrence for the reported event, if exact time of occurrence is unknown

    private String CMPLNT_TO_TM; //Ending time of occurrence for the reported event, if exact time of occurrence is unknown

    private String ADDR_PCT_CD; //The precinct in which the incident occurred

    private String RPT_DT; //Date event was reported to police

    private String KY_CD; //Three digit offense classification code

    private String OFNS_DESC; //Description of offense corresponding with key code

    private String PD_CD; //Three digit internal classification code (more granular than Key Code)

    private String PD_DESC; //Description of internal classification corresponding with PD code (more granular than Offense Description)

    private String CRM_ATPT_CPTD_CD; //Indicator of whether crime was successfully completed or attempted, but failed or was interrupted prematurely

    private String LAW_CAT_CD; //Level of offense: felony, misdemeanor, violation

    private String BORO_NM; //The name of the borough in which the incident occured

    private String LOC_OF_OCCUR_DESC; //Specific location of occurrence in or around the premises; inside, opposite of, front of, rear of

    private String PREM_TYP_DESC; //Specific description of premises; grocery store, residence, street, etc.

    private String JURIS_DESC; //Jurisdiction responsible for incident. Either internal, like Police, Transit, and Housing; or external, like Correction, Port Authority, etc.

    private String JURISDICTION_CODE; // Jurisdiction responsible for incident. Either internal, like Police(0), Transit(1), and Housing(2); or external(3), like Correction, Port Authority, etc.

    private String PARKS_NM; //Name of NYC park, playground or greenspace of occurrence, if applicable (state parks are not included)

    private String HADEVELOPT; //Name of NYCHA housing development of occurrence, if applicable

    private String HOUSING_PSA; //Development Level Code

    private String X_COORD_CD; //X-coordinate for New York State Plane Coordinate System, Long Island Zone, NAD 83, units feet (FIPS 3104)

    private String Y_COORD_CD; //Y-coordinate for New York State Plane Coordinate System, Long Island Zone, NAD 83, units feet (FIPS 3104)

    private String SUSP_AGE_GROUP; //Suspect’s Age Group

    private String SUSP_RACE; //Suspect’s Race Description

    private String SUSP_SEX; //Suspect’s Sex Description

    private String TRANSIT_DISTRICT; // Transit district in which the offense occurred.

    private String Latitude; //Midblock Latitude coordinate for Global Coordinate System, WGS 1984, decimal degrees (EPSG 4326)

    private String Longitude; //Midblock Longitude coordinate for Global Coordinate System, WGS 1984, decimal degrees (EPSG 4326)

    private String Lat_Lon; //Geospatial Location Point (latitude and Longitude combined)

    private String PATROL_BORO; //The name of the patrol borough in which the incident occurred

    private String STATION_NAME; //Transit station name

    private String VIC_AGE_GROUP; //Victim’s Age Group

    private String VIC_RACE; //Victim’s Race Description

    private String VIC_SEX; //Victim’s Sex Description

    public Information() {
    }

    public Information(String CMPLNT_NUM, String CMPLNT_FR_DT, String CMPLNT_FR_TM, String CMPLNT_TO_DT, String CMPLNT_TO_TM, String ADDR_PCT_CD, String RPT_DT, String OFNS_DESC, String PD_CD, String KY_CD, String PD_DESC, String CRM_ATPT_CPTD_CD, String LAW_CAT_CD, String BORO_NM, String LOC_OF_OCCUR_DESC, String PREM_TYP_DESC, String JURIS_DESC, String JURISDICTION_CODE, String PARKS_NM, String HADEVELOPT, String HOUSING_PSA, String y_COORD_CD, String x_COORD_CD, String SUSP_AGE_GROUP, String SUSP_RACE, String SUSP_SEX, String TRANSIT_DISTRICT, String latitude, String longitude, String lat_Lon, String PATROL_BORO, String STATION_NAME, String VIC_AGE_GROUP, String VIC_RACE, String VIC_SEX) {
        super();
        this.CMPLNT_NUM = CMPLNT_NUM;
        this.CMPLNT_FR_DT = CMPLNT_FR_DT;
        this.CMPLNT_FR_TM = CMPLNT_FR_TM;
        this.CMPLNT_TO_DT = CMPLNT_TO_DT;
        this.CMPLNT_TO_TM = CMPLNT_TO_TM;
        this.ADDR_PCT_CD = ADDR_PCT_CD;
        this.RPT_DT = RPT_DT;
        this.KY_CD = KY_CD;
        this.OFNS_DESC = OFNS_DESC;
        this.PD_CD = PD_CD;
        this.PD_DESC = PD_DESC;
        this.CRM_ATPT_CPTD_CD = CRM_ATPT_CPTD_CD;
        this.LAW_CAT_CD = LAW_CAT_CD;
        this.BORO_NM = BORO_NM;
        this.LOC_OF_OCCUR_DESC = LOC_OF_OCCUR_DESC;
        this.PREM_TYP_DESC = PREM_TYP_DESC;
        this.JURIS_DESC = JURIS_DESC;
        this.JURISDICTION_CODE = JURISDICTION_CODE;
        this.PARKS_NM = PARKS_NM;
        this.HADEVELOPT = HADEVELOPT;
        this.HOUSING_PSA = HOUSING_PSA;
        X_COORD_CD = x_COORD_CD;
        Y_COORD_CD = y_COORD_CD;
        this.SUSP_AGE_GROUP = SUSP_AGE_GROUP;
        this.SUSP_RACE = SUSP_RACE;
        this.SUSP_SEX = SUSP_SEX;
        this.TRANSIT_DISTRICT = TRANSIT_DISTRICT;
        Latitude = latitude;
        Longitude = longitude;
        Lat_Lon = lat_Lon;
        this.PATROL_BORO = PATROL_BORO;
        this.STATION_NAME = STATION_NAME;
        this.VIC_AGE_GROUP = VIC_AGE_GROUP;
        this.VIC_RACE = VIC_RACE;
        this.VIC_SEX = VIC_SEX;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        String newLine = System.getProperty("line.separator");
        result.append(this.getClass().getName());
        result.append(" Object {");
        result.append(newLine);

        Field[] fields = this.getClass().getDeclaredFields();
        for (Field field : fields) {
            result.append("  ");
            try {
                result.append(field.getName());
                result.append(": ");
                result.append(field.get(this));
            } catch (IllegalAccessException ex) {
                System.out.println(ex);
            }
            result.append(newLine);
        }
        result.append("}");
        return result.toString();
    }

    public String getCMPLNT_NUM() {
        return CMPLNT_NUM;
    }

    public void setCMPLNT_NUM(String CMPLNT_NUM) {
        this.CMPLNT_NUM = CMPLNT_NUM;
    }

    public String getCMPLNT_FR_DT() {
        return CMPLNT_FR_DT;
    }

    public void setCMPLNT_FR_DT(String CMPLNT_FR_DT) {
        this.CMPLNT_FR_DT = CMPLNT_FR_DT;
    }

    public String getCMPLNT_FR_TM() {
        return CMPLNT_FR_TM;
    }

    public void setCMPLNT_FR_TM(String CMPLNT_FR_TM) {
        this.CMPLNT_FR_TM = CMPLNT_FR_TM;
    }

    public String getCMPLNT_TO_DT() {
        return CMPLNT_TO_DT;
    }

    public void setCMPLNT_TO_DT(String CMPLNT_TO_DT) {
        this.CMPLNT_TO_DT = CMPLNT_TO_DT;
    }

    public String getCMPLNT_TO_TM() {
        return CMPLNT_TO_TM;
    }

    public void setCMPLNT_TO_TM(String CMPLNT_TO_TM) {
        this.CMPLNT_TO_TM = CMPLNT_TO_TM;
    }

    public String getADDR_PCT_CD() {
        return ADDR_PCT_CD;
    }

    public void setADDR_PCT_CD(String ADDR_PCT_CD) {
        this.ADDR_PCT_CD = ADDR_PCT_CD;
    }

    public String getRPT_DT() {
        return RPT_DT;
    }

    public void setRPT_DT(String RPT_DT) {
        this.RPT_DT = RPT_DT;
    }

    public String getKY_CD() {
        return KY_CD;
    }

    public void setKY_CD(String KY_CD) {
        this.KY_CD = KY_CD;
    }

    public String getOFNS_DESC() {
        return OFNS_DESC;
    }

    public void setOFNS_DESC(String OFNS_DESC) {
        this.OFNS_DESC = OFNS_DESC;
    }

    public String getPD_CD() {
        return PD_CD;
    }

    public void setPD_CD(String PD_CD) {
        this.PD_CD = PD_CD;
    }

    public String getPD_DESC() {
        return PD_DESC;
    }

    public void setPD_DESC(String PD_DESC) {
        this.PD_DESC = PD_DESC;
    }

    public String getCRM_ATPT_CPTD_CD() {
        return CRM_ATPT_CPTD_CD;
    }

    public void setCRM_ATPT_CPTD_CD(String CRM_ATPT_CPTD_CD) {
        this.CRM_ATPT_CPTD_CD = CRM_ATPT_CPTD_CD;
    }

    public String getLAW_CAT_CD() {
        return LAW_CAT_CD;
    }

    public void setLAW_CAT_CD(String LAW_CAT_CD) {
        this.LAW_CAT_CD = LAW_CAT_CD;
    }

    public String getBORO_NM() {
        return BORO_NM;
    }

    public void setBORO_NM(String BORO_NM) {
        this.BORO_NM = BORO_NM;
    }

    public String getLOC_OF_OCCUR_DESC() {
        return LOC_OF_OCCUR_DESC;
    }

    public void setLOC_OF_OCCUR_DESC(String LOC_OF_OCCUR_DESC) {
        this.LOC_OF_OCCUR_DESC = LOC_OF_OCCUR_DESC;
    }

    public String getPREM_TYP_DESC() {
        return PREM_TYP_DESC;
    }

    public void setPREM_TYP_DESC(String PREM_TYP_DESC) {
        this.PREM_TYP_DESC = PREM_TYP_DESC;
    }

    public String getJURIS_DESC() {
        return JURIS_DESC;
    }

    public void setJURIS_DESC(String JURIS_DESC) {
        this.JURIS_DESC = JURIS_DESC;
    }

    public String getJURISDICTION_CODE() {
        return JURISDICTION_CODE;
    }

    public void setJURISDICTION_CODE(String JURISDICTION_CODE) {
        this.JURISDICTION_CODE = JURISDICTION_CODE;
    }

    public String getPARKS_NM() {
        return PARKS_NM;
    }

    public void setPARKS_NM(String PARKS_NM) {
        this.PARKS_NM = PARKS_NM;
    }

    public String getHADEVELOPT() {
        return HADEVELOPT;
    }

    public void setHADEVELOPT(String HADEVELOPT) {
        this.HADEVELOPT = HADEVELOPT;
    }

    public String getHOUSING_PSA() {
        return HOUSING_PSA;
    }

    public void setHOUSING_PSA(String HOUSING_PSA) {
        this.HOUSING_PSA = HOUSING_PSA;
    }

    public String getX_COORD_CD() {
        return X_COORD_CD;
    }

    public void setX_COORD_CD(String x_COORD_CD) {
        X_COORD_CD = x_COORD_CD;
    }

    public String getY_COORD_CD() {
        return Y_COORD_CD;
    }

    public void setY_COORD_CD(String y_COORD_CD) {
        Y_COORD_CD = y_COORD_CD;
    }

    public String getSUSP_AGE_GROUP() {
        return SUSP_AGE_GROUP;
    }

    public void setSUSP_AGE_GROUP(String SUSP_AGE_GROUP) {
        this.SUSP_AGE_GROUP = SUSP_AGE_GROUP;
    }

    public String getSUSP_RACE() {
        return SUSP_RACE;
    }

    public void setSUSP_RACE(String SUSP_RACE) {
        this.SUSP_RACE = SUSP_RACE;
    }

    public String getSUSP_SEX() {
        return SUSP_SEX;
    }

    public void setSUSP_SEX(String SUSP_SEX) {
        this.SUSP_SEX = SUSP_SEX;
    }

    public String getTRANSIT_DISTRICT() {
        return TRANSIT_DISTRICT;
    }

    public void setTRANSIT_DISTRICT(String TRANSIT_DISTRICT) {
        this.TRANSIT_DISTRICT = TRANSIT_DISTRICT;
    }

    public String getLatitude() {
        return Latitude;
    }

    public void setLatitude(String latitude) {
        Latitude = latitude;
    }

    public String getLongitude() {
        return Longitude;
    }

    public void setLongitude(String longitude) {
        Longitude = longitude;
    }

    public String getLat_Lon() {
        return Lat_Lon;
    }

    public void setLat_Lon(String lat_Lon) {
        Lat_Lon = lat_Lon;
    }

    public String getPATROL_BORO() {
        return PATROL_BORO;
    }

    public void setPATROL_BORO(String PATROL_BORO) {
        this.PATROL_BORO = PATROL_BORO;
    }

    public String getSTATION_NAME() {
        return STATION_NAME;
    }

    public void setSTATION_NAME(String STATION_NAME) {
        this.STATION_NAME = STATION_NAME;
    }

    public String getVIC_AGE_GROUP() {
        return VIC_AGE_GROUP;
    }

    public void setVIC_AGE_GROUP(String VIC_AGE_GROUP) {
        this.VIC_AGE_GROUP = VIC_AGE_GROUP;
    }

    public String getVIC_RACE() {
        return VIC_RACE;
    }

    public void setVIC_RACE(String VIC_RACE) {
        this.VIC_RACE = VIC_RACE;
    }

    public String getVIC_SEX() {
        return VIC_SEX;
    }

    public void setVIC_SEX(String VIC_SEX) {
        this.VIC_SEX = VIC_SEX;
    }
}