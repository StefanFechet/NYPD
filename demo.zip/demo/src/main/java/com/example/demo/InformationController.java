package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Random;

@RestController
public class InformationController {

    @Autowired
    private CrimeDAO crimeDao;

    @GetMapping(path = "/dataset/stats/total", produces = "application/json")
    public int getNoOfCrimes() {
        int n = crimeDao.getAllCrimes().getCrimesList().size();
        if (n > 0)
            return n - 1;
        return 0;
    }

    @GetMapping(path = "/dataset/stats/offenses", produces = "application/json")
    public Map<Integer, Integer> getNoOfOffenses() {
        crimeDao.getAllCrimes();
        return crimeDao.getOffenses();
    }

    @DeleteMapping(path = "/dataset/{id}")
    @ResponseBody
    public boolean deleteID(@PathVariable("id") String id) {
        int i = 0;
        for (String s : crimeDao.getAllCrimes().getCrimesList()) {
            i++;
            if (s.contains("CMPLNT_NUM: " + id + "\n")) {
                crimeDao.getAllCrimes().getCrimesList().remove(s);
                crimeDao.removeFromTree(s);
                return crimeDao.delete(String.valueOf(i));
            }
        }
        return false;
    }

    @RequestMapping(value = "/dataset", method = RequestMethod.POST)
    public void customerInformation(@RequestBody Little_Information little_informationinformation) {
        Information information = new Information();
        information.setCMPLNT_NUM(String.valueOf(crimeDao.generateSpecialRandom()));
        information.setKY_CD(String.valueOf(new Random().nextInt(900) + 100));
        crimeDao.addCrime(information.toString());
        crimeDao.addToTree(information);
        crimeDao.writeFile(information);
        little_informationinformation.setCMPLNT_NUM(information.getCMPLNT_NUM());
        little_informationinformation.setKY_CD(information.getKY_CD());
    }
}