package com.example.demo;

import java.util.LinkedHashSet;
import java.util.Set;

public class All_Crimes {

    private Set<String> crimes;

    public Set<String> getCrimesList() {
        if (crimes == null) {
            crimes = new LinkedHashSet<>();
        }
        return crimes;
    }

    public void setCrimes(Set<String> crimes) {
        this.crimes = crimes;
    }
}
